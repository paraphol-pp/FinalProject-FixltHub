var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/node_modules_next_a1a33131._.js")
R.c("server/chunks/[root-of-the-server]__cf972329._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_login_route_actions_d02a8f19.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/auth/login/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/auth/login/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
