var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/me/route.js")
R.c("server/chunks/node_modules_next_9bc25665._.js")
R.c("server/chunks/[root-of-the-server]__a334a469._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_me_route_actions_97ac7615.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/auth/me/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/auth/me/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
