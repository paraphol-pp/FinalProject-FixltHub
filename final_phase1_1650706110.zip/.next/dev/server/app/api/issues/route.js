var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/issues/route.js")
R.c("server/chunks/node_modules_next_18c72dc8._.js")
R.c("server/chunks/[root-of-the-server]__4fe99859._.js")
R.c("server/chunks/_next-internal_server_app_api_issues_route_actions_b0b46939.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/issues/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/issues/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
