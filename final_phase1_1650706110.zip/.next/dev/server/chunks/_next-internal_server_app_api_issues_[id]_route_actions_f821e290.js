module.exports = [
"[project]/.next-internal/server/app/api/issues/[id]/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_issues_%5Bid%5D_route_actions_f821e290.js.map