(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_6e67b69d._.js",
  "static/chunks/app_dfbbda88._.js"
],
    source: "dynamic"
});
