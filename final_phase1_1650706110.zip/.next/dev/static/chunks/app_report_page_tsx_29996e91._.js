(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_c3959e90._.js",
  "static/chunks/app_components_Report_tsx_7f4462cd._.js"
],
    source: "dynamic"
});
