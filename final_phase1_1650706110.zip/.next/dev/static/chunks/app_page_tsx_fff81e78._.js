(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_8d3b32fe._.js",
  "static/chunks/node_modules_a0135d44._.js"
],
    source: "dynamic"
});
