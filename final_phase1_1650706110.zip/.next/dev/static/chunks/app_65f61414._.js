(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/components/Footer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const Footer = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: "bg-neutral-950 border-t border-white/5 py-12",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-6 text-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-center gap-2 font-bold text-2xl tracking-tighter mb-8 text-white",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-gradient-to-bl from-pink-500  to-orange-500 px-3 py-1 rounded-lg text-white font-bold",
                            children: "F"
                        }, void 0, false, {
                            fileName: "[project]/app/components/Footer.tsx",
                            lineNumber: 6,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-2xl font-bold",
                            children: [
                                "FixIt ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-white/60",
                                    children: "Hub"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/Footer.tsx",
                                    lineNumber: 11,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/Footer.tsx",
                            lineNumber: 10,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/Footer.tsx",
                    lineNumber: 5,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-center gap-8 text-neutral-500 text-sm mb-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: "#",
                            className: "hover:text-white transition-colors",
                            children: "Privacy Policy"
                        }, void 0, false, {
                            fileName: "[project]/app/components/Footer.tsx",
                            lineNumber: 15,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: "#",
                            className: "hover:text-white transition-colors",
                            children: "Terms of Service"
                        }, void 0, false, {
                            fileName: "[project]/app/components/Footer.tsx",
                            lineNumber: 18,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: "#",
                            className: "hover:text-white transition-colors",
                            children: "Contact Support"
                        }, void 0, false, {
                            fileName: "[project]/app/components/Footer.tsx",
                            lineNumber: 21,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/Footer.tsx",
                    lineNumber: 14,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-neutral-600 text-sm",
                    children: [
                        "© 2025 FixIt Community. Design inspired by",
                        " ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-orange-500",
                            children: "Paraphol."
                        }, void 0, false, {
                            fileName: "[project]/app/components/Footer.tsx",
                            lineNumber: 27,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/Footer.tsx",
                    lineNumber: 25,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/Footer.tsx",
            lineNumber: 4,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/app/components/Footer.tsx",
        lineNumber: 3,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Footer;
const __TURBOPACK__default__export__ = Footer;
var _c;
__turbopack_context__.k.register(_c, "Footer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/store/issueStoretest.ts [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

// // app/store/issueStore.ts
// "use client";
// import { create } from "zustand";
// export type IssueStatus = "Pending" | "In Progress" | "Resolved";
// export type IssueCategory =
//   | "Electrical"
//   | "Water Supply"
//   | "Roads"
//   | "Waste"
//   | "Safety"
//   | "Others";
// export type Issue = {
//   id: number;
//   title: string;
//   location: string;
//   date: string;
//   description: string;
//   category: IssueCategory;
//   status: IssueStatus;
//   reporter: string;
//   imageUrl: string;
// };
// const initialIssues: Issue[] = [
//   {
//     id: 1,
//     title: "Street Light Broken at Main St. & 5th Ave",
//     location: "Main St. & 5th Ave",
//     date: "11/14/2025",
//     description:
//       "Reported issue concerning street light broken. Ideally requires immediate inspection to prevent accidents.",
//     category: "Electrical",
//     status: "Pending",
//     reporter: "Citizen A",
//     imageUrl: "/assets/issues/issue-1.avif",
//   },
//   {
//     id: 2,
//     title: "Water Pipe Burst at Central Park Entrance",
//     location: "Central Park Entrance",
//     date: "11/12/2025",
//     description:
//       "Reported issue concerning water pipe burst. May cause flooding and water supply disruption.",
//     category: "Water Supply",
//     status: "Pending",
//     reporter: "Citizen B",
//     imageUrl: "/assets/issues/issue-2.avif",
//   },
//   {
//     id: 3,
//     title: "Manhole Cover Missing at Downtown Market",
//     location: "Downtown Market",
//     date: "08/19/2025",
//     description:
//       "Reported manhole cover missing. Immediate attention needed to avoid accidents for pedestrians and vehicles.",
//     category: "Roads",
//     status: "Pending",
//     reporter: "Citizen C",
//     imageUrl: "/assets/issues/issue-3.jpg",
//   },
//   {
//     id: 4,
//     title: "Overflowing Trash at School Zone A",
//     location: "School Zone A",
//     date: "11/14/2025",
//     description:
//       "Reported overflowing trash near the school area. Could impact hygiene and student safety.",
//     category: "Waste",
//     status: "Pending",
//     reporter: "Citizen D",
//     imageUrl: "/assets/issues/issue-4.avif",
//   },
//   {
//     id: 5,
//     title: "Fallen Tree at Riverside Walkway",
//     location: "Riverside Walkway",
//     date: "08/19/2025",
//     description:
//       "Reported fallen tree blocking pedestrian walkway. Requires urgent clearing for safe passage.",
//     category: "Safety",
//     status: "Pending",
//     reporter: "Citizen E",
//     imageUrl: "/assets/issues/issue-5.avif",
//   },
//   {
//     id: 6,
//     title: "Pothole on Road at Block 5, Sector 2",
//     location: "Block 5, Sector 2",
//     date: "08/12/2025",
//     description:
//       "Reported large pothole on main road. Could damage vehicles and cause traffic issues.",
//     category: "Others",
//     status: "In Progress",
//     reporter: "Citizen F",
//     imageUrl: "/assets/issues/issue-6.avif",
//   },
//   {
//     id: 7,
//     title: "Flooding Under Highway Exit 12",
//     location: "Highway Exit 12",
//     date: "09/02/2025",
//     description:
//       "Heavy water accumulation during rain causing hazardous driving conditions.",
//     category: "Roads",
//     status: "Pending",
//     reporter: "Citizen G",
//     imageUrl: "/assets/issues/issue-7.avif",
//   },
//   {
//     id: 8,
//     title: "Broken Guardrail at Riverside Curve",
//     location: "Riverside Curve",
//     date: "10/01/2025",
//     description:
//       "Damaged guardrail along sharp curve by the river. Needs repair to ensure driver safety.",
//     category: "Safety",
//     status: "In Progress",
//     reporter: "Citizen H",
//     imageUrl: "/assets/issues/issue-8.jpg",
//   },
//   {
//     id: 9,
//     title: "Clogged Drain Causing Street Flooding",
//     location: "Market Street",
//     date: "11/01/2025",
//     description:
//       "Drainage blocked by debris leading to frequent street flooding during rainfall.",
//     category: "Waste",
//     status: "Resolved",
//     reporter: "Citizen I",
//     imageUrl: "/assets/issues/issue-9.avif",
//   },
//   {
//     id: 10,
//     title: "Clogged Drain Causing Street Flooding",
//     location: "Market Street",
//     date: "11/01/2025",
//     description:
//       "Drainage blocked by debris leading to frequent street flooding during rainfall.",
//     category: "Waste",
//     status: "Resolved",
//     reporter: "Citizen I",
//     imageUrl: "/assets/issues/issue-9.avif",
//   },
//   {
//     id: 11,
//     title: "Clogged Drain Causing Street Flooding",
//     location: "Market Street",
//     date: "11/01/2025",
//     description:
//       "Drainage blocked by debris leading to frequent street flooding during rainfall.",
//     category: "Waste",
//     status: "Resolved",
//     reporter: "Citizen I",
//     imageUrl: "/assets/issues/issue-9.avif",
//   },
//   {
//     id: 12,
//     title: "Clogged Drain Causing Street Flooding",
//     location: "Market Street",
//     date: "11/01/2025",
//     description:
//       "Drainage blocked by debris leading to frequent street flooding during rainfall.",
//     category: "Waste",
//     status: "Resolved",
//     reporter: "Citizen I",
//     imageUrl: "/assets/issues/issue-9.avif",
//   },
//   {
//     id: 13,
//     title: "Clogged Drain Causing Street Flooding",
//     location: "Market Street",
//     date: "11/01/2025",
//     description:
//       "Drainage blocked by debris leading to frequent street flooding during rainfall.",
//     category: "Waste",
//     status: "Resolved",
//     reporter: "Citizen I",
//     imageUrl: "/assets/issues/issue-9.avif",
//   },
// ];
// type IssueStore = {
//   issues: Issue[];
//   addIssue: (issue: Omit<Issue, "id">) => void;
//   updateIssue: (id: number, data: Partial<Issue>) => void;
//   deleteIssue: (id: number) => void;
// };
// export const useIssueStore = create<IssueStore>((set) => ({
//   issues: initialIssues,
//   addIssue: (issue) =>
//     set((state) => {
//       const nextId =
//         state.issues.length > 0
//           ? Math.max(...state.issues.map((i) => i.id)) + 1
//           : 1;
//       return { issues: [...state.issues, { ...issue, id: nextId }] };
//     }),
//   updateIssue: (id, data) =>
//     set((state) => ({
//       issues: state.issues.map((issue) =>
//         issue.id === id ? { ...issue, ...data } : issue
//       ),
//     })),
//   deleteIssue: (id) =>
//     set((state) => ({
//       issues: state.issues.filter((issue) => issue.id !== id),
//     })),
// }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/report/page.tsx [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

const e = new Error("Could not parse module '[project]/app/report/page.tsx'\n\nReturn statement is not allowed here");
e.code = 'MODULE_UNPARSABLE';
throw e;
}),
]);

//# sourceMappingURL=app_65f61414._.js.map