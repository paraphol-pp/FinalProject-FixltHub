(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_1d0ce6c3._.js",
  "static/chunks/app_components_3ef8c145._.js"
],
    source: "dynamic"
});
