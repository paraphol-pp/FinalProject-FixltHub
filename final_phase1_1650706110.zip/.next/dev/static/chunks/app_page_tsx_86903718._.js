(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_b9501053._.js",
  "static/chunks/app_components_fc7e6afc._.js"
],
    source: "dynamic"
});
