-- AlterTable
ALTER TABLE `Issue` ADD COLUMN `updatedAt` DATETIME(3) NULL;
