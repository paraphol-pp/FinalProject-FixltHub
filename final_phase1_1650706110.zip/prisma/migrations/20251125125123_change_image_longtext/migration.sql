-- AlterTable
ALTER TABLE `Issue` MODIFY `imageUrl` LONGTEXT NOT NULL;
